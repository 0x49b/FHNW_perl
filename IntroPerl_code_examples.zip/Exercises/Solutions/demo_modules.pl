#! /usr/bin/env perl

use 5.026;
use warnings;
use experimentals;

use My::Module 'my_sub', 'my_other_sub';

my_sub();

my_other_sub();
